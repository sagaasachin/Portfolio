
import Card from "./Components/portfolio/card"
import Header from "./Components/portfolio/header"
import Certifi from "./Components/portfolio/certifi"
import About from "./Components/portfolio/about"
import ContactPage from "./Components/portfolio/contact"
import Footer from "./Components/portfolio/footer"



function App() {


  return (
    <>
      <Header />
      <About />
      <Card />
      <Certifi />
      <ContactPage />
      <Footer />

      

    </>
  )
}

export default App

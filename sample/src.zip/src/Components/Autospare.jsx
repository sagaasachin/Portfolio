import React from 'react';
import {
  AppBar,
  Toolbar,
  IconButton,
  Typography,
  InputBase,
  Badge,
  Box,
  Stack,
  alpha,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import SearchIcon from '@mui/icons-material/Search';
import DirectionsCarFilledIcon from '@mui/icons-material/DirectionsCar';
import bg from '../assets/car spare.jpg'

const Autospare = () => {
   // Replace with your image URL

  return (
    <Box
      sx={{
        flexGrow: 1,
        backgroundImage: `url(${bg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        color: '#fff',
      }}
    >
      {/* Overlay to improve contrast */}
      <Box
        sx={{
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          width: '100%',
        }}
      >
        {/* Top Toolbar: Menu + Logo + Cart */}
        <AppBar position="static" elevation={0} sx={{ background: 'transparent' }}>
          <Toolbar sx={{ justifyContent: 'space-between' }}>
            <Stack direction="row" spacing={2} alignItems="center">
              <IconButton edge="start" color="inherit" aria-label="menu">
                <MenuIcon />
              </IconButton>
              <DirectionsCarFilledIcon />
            </Stack>

            <IconButton size="large" aria-label="show cart items" color="inherit">
              <Badge badgeContent={3} color="error">
                <ShoppingCartIcon />
              </Badge>
            </IconButton>
          </Toolbar>
        </AppBar>

        {/* Company Name */}
        <Box sx={{ py: 2 }}>
          <Typography variant="h4" align="center" fontWeight="bold" color="inherit">
            AutoSpare Hub
          </Typography>
        </Box>

        {/* Search Bar */}
        <Box sx={{ display: 'flex', justifyContent: 'center', pb: 4, px: 2 }}>
          <Box
            sx={{
              position: 'relative',
              borderRadius: 1,
              backgroundColor: alpha('#fff', 0.15),
              '&:hover': {
                backgroundColor: alpha('#fff', 0.25),
              },
              width: { xs: '90%', sm: '70%', md: '50%' },
              display: 'flex',
              alignItems: 'center',
              px: 2,
              py: 0.5,
            }}
          >
            <SearchIcon sx={{ mr: 1, color: '#fff' }} />
            <InputBase
              placeholder="Search spare parts..."
              inputProps={{ 'aria-label': 'search' }}
              sx={{ color: '#fff', width: '100%' }}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Autospare;

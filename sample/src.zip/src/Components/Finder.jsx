import React, { useState } from 'react';
import a from '../assets/dress.jpg'

const users = [
  {
    id: 'user1',
    name: 'User 1',
    image: a, // Place this in your public folder
    parts: [
      { id: 1, part: 'shirt', label: 'Shirt', x: 100, y: 150 },
      { id: 2, part: 'watch', label: 'Watch', x: 180, y: 170 },
      { id: 3, part: 'cap', label: 'Cap', x: 120, y: 70 },
      { id: 4, part: 'shoe', label: 'Shoe', x: 100, y: 300 },
    ],
  },
  {
    id: 'user2',
    name: 'User 2',
    image:a, // Place this in your public folder
    parts: [
      { id: 5, part: 'shirt', label: 'Shirt', x: 90, y: 150 },
      { id: 6, part: 'watch', label: 'Watch', x: 160, y: 170 },
      { id: 7, part: 'cap', label: 'Cap', x: 110, y: 60 },
      { id: 8, part: 'shoe', label: 'Shoe', x: 90, y: 300 },
    ],
  },
];

// Amazon links for parts
const partLinks = {
  shirt: 'https://www.amazon.com/s?k=mens+tshirt',
  watch: 'https://www.amazon.com/s?k=mens+watch',
  cap: 'https://www.amazon.com/s?k=mens+cap',
  shoe: 'https://www.amazon.com/s?k=mens+shoe',
};

const Finder = () => {
  const [highlighted, setHighlighted] = useState(null);

  return (
    <div style={{ display: 'flex', gap: '40px', justifyContent: 'center', padding: '40px' }}>
      {users.map((user) => (
        <div key={user.id} style={{ position: 'relative', width: '300px' }}>
          <img src={user.image} alt={user.name} style={{ width: '100%' }} />
          {user.parts.map(({ id, part, label, x, y }) => (
            <a
              key={id}
              href={partLinks[part]}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setHighlighted(part)}
              style={{
                position: 'absolute',
                left: x,
                top: y,
                backgroundColor:
                  highlighted === part ? 'yellow' : 'rgba(255,255,255,0.7)',
                padding: '4px 8px',
                border: '1px solid #333',
                textDecoration: 'none',
                color: '#000',
                fontSize: '12px',
                borderRadius: '4px',
                transition: 'background 0.2s',
              }}
            >
              {label}
            </a>
          ))}
        </div>
      ))}
    </div>
  );
};

export default Finder;

import React from 'react'
import "./Skill.css"
import a from '../assets/study.jpg'

function Skill(props) {
  return (
    <>
        

        <div className="contain">

          {/* <button type='radio'></button> */}
            
                 <img src={a}alt="" />
           
            <h1>{props.id}</h1>
            <p>{props.title}</p>
            <h1 id='user'>Id :{props.userId}</h1>
            <h1>{props.price}</h1>
        </div>
     </>
  )
}

export default Skill
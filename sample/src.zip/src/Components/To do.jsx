import React, { useState } from 'react';
import './Todo.css'

function Todo() {
  const [tasks, setTasks] = useState([]); // Incomplete tasks
  const [completedTasks, setCompletedTasks] = useState([]); // Completed tasks
  const [task, setTask] = useState(''); // Current input

  const handleChange = (e) => {
    setTask(e.target.value);
  };

  const add = () => {
    if (task.trim() !== '') {
      setTasks([...tasks, task]);
      setTask('');
    }
  };

  const removeTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index));
  };

  const completeTask = (index) => {
    const completed = tasks[index];
    setCompletedTasks([...completedTasks, completed]);
    setTasks(tasks.filter((_, i) => i !== index));
  };

  const removeCompletedTask = (index) => {
    setCompletedTasks(completedTasks.filter((_, i) => i !== index));
  };

  return (
    <>
      <div className="todo">
      <h1 className='heading' >TO DO LIST</h1>
      <input className='in' 
        type="text"
        value={task}
        onChange={handleChange}
        placeholder="Enter a task"
      />
      
      <button className='btn btn-outline-success ms-3' onClick={add}>Add</button>

      <ul>
      </ul> 
        {tasks.map((t, index) => (
          <div className="values">
          <li key={index}>
            {t}{' '}
            <button className='btn btn-outline-danger' onClick={() => removeTask(index)}>Delete</button>
            <button className='btn btn-outline-success ms-3' onClick={() => completeTask(index)}>Complete</button>
          </li>
          </div>
        ))}
      {/* </ul> */}

      
      <h2>COMPLETED TASKS</h2>
      <ul>
        {completedTasks.map((t, index) => (
          <div className="val">
          <li key={index}>
            {t}{' '}
            <button className='btn btn-outline-danger' onClick={() => removeCompletedTask(index)}>Remove</button>
          </li>
          </div>
        ))}
      </ul>

      </div>
     
    </>
  );
}

export default Todo;



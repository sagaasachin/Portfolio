import React, { useState } from 'react'

function car() {
    const[value,setValue]=useState([])
    const [car,setCar]=useState({
        bike:" ",
        model:" ",
        color:" ",
    })
    const handlechange=(e)=>{
        setCar({...car,[e.target.name]:e.target.value})

    }
    const add=()=>{
        setValue([...value,{...car}])
        setCar({bike:"",model:"",color:""})
    }
    
  return (
    <>
        <input type="text" value={car.bike} name='bike' onChange={handlechange}  />
        <input type="text" value={car.model} name='model' onChange={handlechange}  />
        <input type="text" value={car.color} name='color' onChange={handlechange}  />

        <button onClick={add}>add</button>

        <ul>
        {value.map((val,index)=>(
            <li key={index}>{val.bike} {val.model} {val.color}</li>
        ))}
        </ul>
        
    </>
  )
}

export default car
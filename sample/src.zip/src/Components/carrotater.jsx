import React, { useState, useRef, useEffect } from 'react';

const Car360Rotator = () => {
  const imageCount = 36;
  const [currentImage, setCurrentImage] = useState(1);
  const circleRef = useRef(null);
  const pointerRef = useRef(null);
  const isDragging = useRef(false);

  const getImageSrc = (index) => {
    const padded = String(index).padStart(3, '0');
    return `/images/car${padded}.jpg`;
  };

  const rotatePointerAndCar = (clientX, clientY) => {
    const circle = circleRef.current;
    const rect = circle.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;

    let angle = Math.atan2(dy, dx) * (180 / Math.PI);
    if (angle < 0) angle += 360;

    // Rotate pointer
    pointerRef.current.style.transform = `rotate(${angle}deg)`;

    // Map angle to image index
    const index = Math.round((angle / 360) * imageCount) + 1;
    setCurrentImage(index > imageCount ? 1 : index);
  };

  const handleMouseDown = (e) => {
    isDragging.current = true;
    rotatePointerAndCar(e.clientX, e.clientY);
  };

  const handleMouseMove = (e) => {
    if (isDragging.current) {
      rotatePointerAndCar(e.clientX, e.clientY);
    }
  };

  const handleMouseUp = () => {
    isDragging.current = false;
  };

  useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  return (
    <div style={{ textAlign: 'center', padding: '20px' }}>
      {/* Circular controller */}
      <div
        ref={circleRef}
        onMouseDown={handleMouseDown}
        style={{
          width: 150,
          height: 150,
          margin: '0 auto 20px',
          border: '3px solid #444',
          borderRadius: '50%',
          position: 'relative',
          cursor: 'grab',
        }}
      >
        {/* Pointer */}
        <div
          ref={pointerRef}
          style={{
            width: '2px',
            height: '70px',
            backgroundColor: 'red',
            position: 'absolute',
            top: '5px',
            left: '50%',
            transformOrigin: 'bottom center',
            transform: 'rotate(0deg)',
          }}
        ></div>
      </div>

      {/* Car image viewer */}
      <div style={{ width: '100%', maxWidth: 800, margin: '0 auto' }}>
        <img
          src={getImageSrc(currentImage)}
          alt="360 view"
          style={{
            width: '100%',
            height: 'auto',
            maxHeight: '600px',
            objectFit: 'contain',
            borderRadius: '10px',
            boxShadow: '0 0 10px rgba(0,0,0,0.3)',
          }}
          draggable={false}
        />
      </div>
    </div>
  );
};

export default Car360Rotator;

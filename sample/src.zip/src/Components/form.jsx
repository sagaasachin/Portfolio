import React, { useState } from 'react'
import "./form.css"

function form() {
    const[name,setName]=useState("")
    const[email,setEmail]=useState("")
    const [dob,setDob]=useState("")
    const [pass,setPass]=useState("")
    const[conpass,setConpass]=useState("")
    const handlechange=(e)=>{
        setName(e.target.value);

    }

    const handlemail=(e)=>{
        setEmail(e.target.value);
    }

    const handledob=(e)=>{
        setDob(e.target.value)
    }

    const handlepass=(e)=>{
        setPass(e.target.value)
    }

    const handlenpass=(e)=>{
        setConpass(e.target.value)
    }


   
   

    
  return (
    <>
        <div className="container">
          <label htmlFor="name">Name</label>
            <input type="text"  name='name' value={name} onChange={handlechange}/>
            <label htmlFor="Email">Email
            <input type=" email" placeholder='email'name='email' value={email} onChange={handlemail} /></label>
            <label htmlFor="DOB">DOB</label>
            <input type="date" placeholder='date of birth'name='dob' value={dob} onChange={handledob} />
            <label htmlFor="password">PASSWORD</label>
            <input type="password" name="password" id="password" value={pass} onChange={handlepass} />
            <label htmlFor="confirm Password">COnfirm PAssword</label>
            <input type="password" placeholder='confirm password' name='cpassword ' value={conpass} onChange={handlenpass}/>

            <button>register</button>
        </div>

        <h1>{name}</h1>
        <h1>{email}</h1>
        <h1>{dob}</h1>
        <h1>{pass}</h1>
        <h1>{conpass}</h1>
    </>
  )
}

export default form;
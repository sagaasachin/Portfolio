import React, { useEffect, useState } from "react";
import Skill from "../Components/Skill";
import not from "../assets/images.jpeg";

function Json() {
    const [val, setVal] = useState(); 
    const [error, setError] = useState(); 

    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/albums')
            .then((response) => {
                if (!response.ok) {
                    throw Error("Failed to fetch")
                }

                return response.json();
            })
            .then((data) => {
                setVal(data);
            })
            .catch((not) => {
                setError(not);
                console.error("Error fetching data:", error);
            });
    }, [])

    if(!val){
        return(
            <>
            
            {error &&  <img src={not} alt="" /> } 

            {!error && 
                
    <div class="loader">
     <div class="justify-content-center jimu-primary-loading">
       
     </div>
    </div>
    }
            </>
        )
    }

    return (
        <>
            <h1>Data album</h1>

        <div className="container">
            {val.map((x,index) => (
                <Skill id={index+1} userId={x.userId} title={x.title} />

                
            ))}
        </div>
        </>
    );
}

export default Json;
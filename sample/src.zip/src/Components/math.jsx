import React from 'react'

function math() {
  return (
    <>
        <input type="radio" name="" id="" />
    </>
  )
}

export default math
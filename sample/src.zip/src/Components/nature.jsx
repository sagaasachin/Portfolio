import React from 'react'
import a from '../assets/foot.jpg'
import b from '../assets/footer.jpg'
import c from '../assets/ui.jpg'
import d from '../assets/ui6.jpg'
import e from '../assets/ui7.jpg'
import f from '../assets/ui8.jpg'
import g from '../assets/ui9.jpg'
import h from '../assets/uii.jpg'

import Skill from '../Components/Skill'
import "./Nature.css"

function Nature( ) {
    const value=[
      {
        image:a,
        title:"Project 1",
        price:"699",
      },
      {
        image:b,
        title:"Project 2",
        head:"hehued",
        price:"199",
        

      },
      {
        image:c,
        
        title:"Project 3",
        price:"4499",

      },
      {
        image:d,
        title:"Project 4",
        head:"hehued",
        price:"399",
       

      },
      {
        image:e,
        title:"Project 5",
        head:"hehued",
        price:"999",
      

      },
      {
        image:f,
        title:"Project 6",
        head:"hehued",
        price:"499",
      

      },
      {
        image:g,
        title:"Project 7",
        head:"hehued",
        price:"299",
       

      },
      {
        image:h,
        title:"Project 8",
        head:"hehued",
        price:"1399",
     

      }
    ]
  
    

  const final =value.map((x)=> <Skill image={x.image}  title={x.title} price={x.price} />)


  
  return (

    <>
    <div className="button">
      <label htmlFor="">
        <input type="radio"/>$299
      </label>
      <label htmlFor="">
        <input type="radio" />$1499
      </label>
      <label htmlFor="">
        <input type="radio" />$1299
      </label>
      
    </div>

      <div className="nature-container">
       
          {final}

      </div>
    </>
  )
}


export default Nature
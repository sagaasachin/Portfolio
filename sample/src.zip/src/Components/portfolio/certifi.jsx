import React from 'react';
import './about.css';
import vdart from '../../assets/vdart.svg'
import il from '../../assets/internz-learn.png'
import tn from '../../assets/tn.png'
import guvi from '../../assets/guvi.webp'
import nm from '../../assets/nm.svg'
import nptel from '../../assets/nptel.jpg'
import info from '../../assets/info.webp'
import sl from '../../assets/sl.jpg'
import online from '../../assets/online.jpg'
import carspare from '../../assets/car spare.jpg'
import ecom from '../../assets/e commerece.jpg'
import insta from '../../assets/insta.jpg'
import Cardhover from './html/cardhover'






function Certifi() {
  // 🟦 Project data
  const projects = [
    { id: '1', title: 'To download certificate',img:il,p: 'Fullstack developer intern',image:vdart },
    { id: '2', title: 'To download certificate', p: 'Fullstack developer intern',image:il},
    { id: '3', title: 'To download certificate', p: 'web development training',image:info },
    { id: '4', title: 'To download certificate', p: 'app development',image:nm},
    { id: '5', title: 'To download certificate', p: 'python for datascience',image:nptel},
    { id: '6', title: 'To download certificate', p: 'introduction to chatgpt',image:guvi },
    { id: '7', title: 'To download certificate', p: 'Python for beginners',image:sl },
    { id: '8', title: 'To download certificate', p: 'Python development',image:tn },
  ];

  // 🟩 Certificate data
  const certificates = [
    { id: '1', p: 'online test platform',image:online},
    { id: '2', p: 'Autospare parts website',image:carspare},
    { id: '3', p: 'e commerece website',image:ecom},
    { id: '4', p: 'clone of instagram',image:insta},
    // { id: '5', p: 'Certificate in UI/UX Design',image:nm },
    // { id: '6', p: 'Certificate in UI/UX Design',image:nptel },
    // { id: '7', p: 'Certificate in UI/UX Design',image:info },
    // { id: '8', p: 'Certificate in UI/UX Design',image:sl },
  ];

  // 🔁 Mapping projects
  const projectCards = projects.map((project) => (
    <div key={project.id} className="card-certificate">
      <img src={project.image} alt="" />
      <p>{project.p}</p>
      <a href={project.img} target='blank'><h1>{project.title}</h1>
      </a>
    </div>
  ));

  // 🔁 Mapping certificates
  const certificateCards = certificates.map((cert) => (
    <div key={cert.id} className="certificate">
      <img src={cert.image} alt="" />
     
     
       <p>{cert.p}</p> 
    </div>
  ));

  return (
    <>
    <div className="Certifi">
      <h1 id='certifi'>earned certificates</h1><br></br>
      {/* <h2>Projects</h2> */}
      <div className="class">
      
        {projectCards}
      </div>
      <h2 id="cer" >projects i have done</h2>
      <div className="certificates">
      
        {certificateCards}
      </div>
      </div>

       {/* <div className="begin">
         <Cardhover/>
        </div> */}
    </>
  );
}

export default Certifi;

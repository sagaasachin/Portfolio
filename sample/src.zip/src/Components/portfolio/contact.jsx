// ContactPage.jsx
import React, { useState } from 'react';
import './ContactPage.css';

const ContactPage = () => {
  // State for form fields
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState('');

  // Handle form field changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulating form submission
    try {
      // Here you would handle actual email sending logic using a backend or email service
      // For demonstration, I will just set a success message
      setTimeout(() => {
        setStatus('Message sent successfully!');
        setIsSubmitting(false);
        setFormData({ name: '', email: '', message: '' }); // Reset the form
      }, 1500);
    } catch (error) {
      setStatus('There was an error sending your message!');
      setIsSubmitting(false);
    }
  };

  return (
    <section className="contact-section" id='cont'>
      <div className="contact-container">
        <h1>Contact Us</h1>
        <p>Feel Free to Share the Your Thoughts </p>
        
        {status && <p className="status-message">{status}</p>}
        
        <form onSubmit={handleSubmit} className="contact-form">
          <div className="form-field">
            <label htmlFor="name">Your Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your name"
              required
            />
          </div>
          
          <div className="form-field">
            <label htmlFor="email">Your Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="Enter your email"
              required
            />
          </div>

          <div className="form-field">
            <label htmlFor="message">Your Message</label>
            <textarea
              id="message"
              name="message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              placeholder="Enter your message"
              required
            />
          </div>
          <div className="contact-button">
          <button type="submit" className="submit-btn" disabled={isSubmitting}>
            {isSubmitting ? 'Sending...' : 'Submit'}
          </button>
          </div>
        </form>
      </div>
    </section>
  );
};

export default ContactPage;

import React from 'react'
import Nav from '../Nav'
import Social from '../social'
import '../Nav.css'
import './Header.css'
import a from '../../assets/Jawahar Sachin.jpg'
import Skill from '../Skill'
// import{Route} from 'react-router-dom'ṇpm run dev
// import {}

function header() {
  return (
   <>
   <div className="header">
    <Nav />
    <a href="#cont"><h1 id='contact'>Contact</h1></a>
    <h1 id='me'>I'm Jawahar Sachin</h1>
    <p>Entry Level Developer</p>
    <img id='naan' src={a} alt="" />
    <div className="soc">
    <Social/>
    </div>
    <div className="cv">
        <h1 id='cv'>to know about me!!</h1>
        <a href="c:\Users\city\Downloads\Jawahar Sachin_resume.pdf" target='blank'><h1 >Download CV</h1></a>
  
    </div>
    </div>
 

   </>
  )
}

export default header
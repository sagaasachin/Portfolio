import React from 'react'

function shoecard() {
  return (
    <>
         
    </>
  )
}

export default shoecard
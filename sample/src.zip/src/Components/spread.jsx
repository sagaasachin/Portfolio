import React, { useState } from 'react'

function spread() {
    const [values,setValues]=useState([])
    const [person,setPerson]=useState({
        firstname :" ",
        lastname :" "
    })
    const handlechange=(e)=>{
        setPerson({...person,[e.target.name]:e.target.value})
    }
    const add=()=>{
        setValues([...values,{...person}])
        setPerson({firstname:"",lastname:""})
        console.log(values,person)
        
    }
  return (
   <>
    <input type="text" name="firstname" onChange={handlechange} value={person.firstname}/>
    <input type="text" name="lastname" onChange={handlechange} value={person.lastname}/>

    <button className='btn btn-outline-success ms-3' onClick={add}>add</button>
    <ul>
        {JSON.stringify(person)}
        {values.map((val,index)=>(
            <li key={index}>{index} 
            {val.firstname}
            {val.lastname}</li>
        ))}
    </ul>
   
   {/* <h1>{firstname}</h1>
   <h1>{lastname}</h1> */}
   </>

  )
}

export default spread